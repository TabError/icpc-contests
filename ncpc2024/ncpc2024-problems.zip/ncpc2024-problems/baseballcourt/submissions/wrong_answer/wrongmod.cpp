#include<bits/stdc++.h>
using namespace std;
typedef vector<int> vi;
typedef vector<vi> vvi;

const int MOD = 1e9 + 5;

int main() {
    cin.tie(NULL); cout.tie(NULL);
    ios_base::sync_with_stdio(false);
    int n, a, b; 
    cin >> n >> a >> b;
    if(n > a * b) { cout << "0\n"; return 0; }
    vvi dp(n + 1, vi(n + 1, 0));
    for(int i = 0; i <= n; ++i)
        dp[i][0] = 1;
    for(int d = 0; d <= n; ++d) {
        for(int m = 1; m <= n; ++m) {
            int k = 1;
            for(; k <= d && k * (d + 1 - k) <= m; ++k) {
                dp[d][m] += dp[d - k][m - k * (d + 1 - k)];
                dp[d][m] %= MOD;
            }
            if(k > d) continue;
            for(k = d; k * (d + 1 - k) <= m; --k) {
                dp[d][m] += dp[d - k][m - k * (d + 1 - k)];
                dp[d][m] %= MOD;
            }
        }
    }
    int ans = 0;
    for(int d = 0; d <= n; ++d) {
        ans += dp[d][n];
        ans %= MOD;
    }
    for(int l = a + 1; l <= n; ++l) {
        for(int k = 1; k * l <= n; ++k) {
            int d = k + l - 1;
            if(d > n) continue;
            ans += MOD - dp[d - k][n - l * k];
            ans %= MOD;
        }
    }
    for(int l = b + 1; l <= n; ++l) {
        for(int k = 1; k * l <= n; ++k) {
            int d = k + l - 1;
            if(d > n) continue;
            ans += MOD - dp[d - k][n - l * k];
            ans %= MOD;
        }
    }
    for(int l1 = a + 1; l1 <= n; ++l1) {
        for(int l2 = b + 1; l2 <= n; ++l2) {
            for(int d = max(l1, l2); d <= n; ++d) {
                int k1 = d - l1 + 1;
                int k2 = d - l2 + 1;
                if(k1 * l1 > n || k2 * l2 > n) break;
                int area = l1 * k1 + l2 * k2 - min(l1, k2) * min(l2, k1);
                if(k1 + k2 > d || area > n) continue;
                ans += dp[d - k1 - k2][n - area];
                ans %= MOD;
            }
        }
    }
    cout << ans << '\n';
}
    
