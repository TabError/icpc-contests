#include<bits/stdc++.h>
using namespace std;

const int MOD = 1e9 + 7;

int backtrack(int n, int d, int a, int b) {
    if(b < 0) return 0;
    if(n == 0) return 1;
    if(n < 0) return 0;
    if(a <= 0) return 0;
    int ans = 0;
    for(int x = 1; x <= min(d, a); ++x) {
        int k = d + 1 - x;
        if(k * x > n) continue;
        ans += backtrack(n - k * x, d - k, x - 1, b - k);
        ans %= MOD;
    }
    return ans;
}

int main() {
    int n, a, b; cin >> n >> a >> b;
    int ans = 0;
    for(int d = 1; d <= n; ++d)
        ans += backtrack(n, d, a, b), ans %= MOD;
    cout << ans << '\n';
}
