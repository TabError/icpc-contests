#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n,m,k;
const int MAXN = 10001;
const ll big = 1000000007;

unordered_map<ll,ll> M;
ll hsh(ll a, ll b, ll c){
    return a*ll(MAXN)*ll(MAXN) + b*ll(MAXN) + c;
}

ll dp(ll a, ll b, ll c){
    if(c == 0)return 1;

    ll h = hsh(a,b,c);
    if(M.find(h) != M.end())return M[h];

    ll ans = 0;
    ll hi = min(ll(n-1), a+b);
    bool done = 0;
    for(ll x = a+1; x <= hi; x++){
        if(x == hi)done = 1;
        ll i = x-a;
        ll extra = i*(b-i+1);
        if(b == m){
            extra = (x+1) * (a+b-x+1);
        }
        if(c-extra < 0)break;
        ans += dp(x, b-i, c-extra);
    }

    if(!done){
        for(ll x = hi; x >= a+1; x--){
            ll i = x-a;
            ll extra = i*(b-i+1);
            if(b == m){
                extra = (x+1) * (a+b-x+1);
            }
            if(c-extra < 0)break;
            ans += dp(x, b-i, c-extra);
        }
    }

    //cerr << a << " " << b << " " << c << "  ----   " << ans << " \n";

    ans %= big;
    M[h] = ans;
    return ans;

}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> k >> n >> m;

    ll ans = 0;
    for(ll sum = 0; sum < n+m-1; sum++){
        ll a = 0;
        ll b = sum;

        if(sum >= m){
            b = m-1;
            a = sum-b;
        }
        ans += dp(a-1, b+1, k);
        ans %= big;
    }
    cout << ans << "\n";

    return 0;
}