#!/usr/bin/python3
import sys
import random

random.seed(int(sys.argv[-1]))
mx = int(sys.argv[1])
n = random.randint(1, mx)
a = random.randint(1, mx)
b = random.randint(1, mx)
print(n)
print(a, b)
