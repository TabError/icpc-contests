#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 20;
const int MAXD = 50;

struct pt{
    int x,y;
};

pt mp(int x, int y){
    pt p;
    p.x = x;
    p.y = y;
    return p;
}

int dist(pt p1, pt p2){
    return abs(p1.x-p2.x) + abs(p1.y-p2.y);
}

int DX[4] = {1,0,-1,0};
int DY[4] = {0,1,0,-1};
string dir_string = ">^<v";

int inv_dir(pt from, pt to){
    if(to.x-from.x == 1)return 0;
    if(to.y-from.y == 1)return 1;
    if(to.x-from.x == -1)return 2;
    if(to.y-from.y == -1)return 3;
    assert(0);
    return -1;
}

vi ANS;

pt start;
vector<pt> points;

vector<pt> visited;
set<pii> SV;

string ans_string = "";

void visit(pt p){
    visited.push_back(p);
    SV.insert({p.x, p.y});
}

bool border(pt p){
    if(SV.find({p.x, p.y}) != SV.end())return 0;
    rep(dx,-1,2){
        rep(dy,-1,2){
            if(SV.find({p.x+dx, p.y+dy}) != SV.end())return 1;
        }
    }
    return 0;
}

void bfs(pt p, map<pii,pii> &parent, vector<pt> &V){
    queue<pt> Q;
    Q.push(p);
    while(!Q.empty()){
        pt pq = Q.front();
        Q.pop();
        rep(c1,0,4){
            int x = pq.x+DX[c1];
            int y = pq.y+DY[c1];
            pt p2 = mp(x, y);
            if(border(p2) && parent.find({x, y}) == parent.end()){
                parent[{x, y}] = {pq.x, pq.y};
                V.push_back(p2);
                Q.push(p2);
            }
        }
    }
}

int score(pt p, int goal){
    if(SV.find({p.x,p.y}) != SV.end())return 2e9;
    rep(c1,goal+1, n){
        // near future points: bad
        if(dist(p, points[c1]) < MAXD)return 1e9+dist(p, points[goal]);
    }
    return dist(p, points[goal]);
}


void solve(int goal){
    ANS.clear();
    // Phase 1: BFS
    map<pii,pii> parent;
    vector<pt> V;
    bfs(start, parent, V);
    pii best;
    int best_dist = 1e9;
    trav(p, V){
        int d = dist(p, points[goal]);
        if(d < best_dist){
            best_dist = d;
            best = {p.x, p.y};
        }
    }

    vector<pt> dfs_path;
    while(1){
        dfs_path.push_back(mp(best.first, best.second));
        if(parent.find(best) == parent.end())break;
        best = parent[best];
    }
    reverse(all(dfs_path));

    rep(c1,1,sz(dfs_path)){
        ANS.push_back(inv_dir(dfs_path[c1-1], dfs_path[c1]));
        visit(dfs_path[c1]);
    }
    start = dfs_path.back();

    // Phase 2: greedy

    while(dist(start, points[goal]) > 0){
        int best_dir = -1;
        int best_score = 2e9-1;
        rep(c1,0,4){
            pt p = mp(start.x+DX[c1], start.y+DY[c1]);
            int temp = score(p, goal);
            if(temp < best_score){
                best_score = temp;
                best_dir = c1;
            }
        }
        assert(best_dir != -1);
        ANS.push_back(best_dir);
        start.x += DX[best_dir];
        start.y += DY[best_dir];
        visit(start);
    }

    trav(i, ANS){
        ans_string += dir_string[i];
    }
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    cin >> n;
    start = mp(0,0);
    assert(n == MAXN);
    visit(start);
    rep(c1,0,n){
        int x,y;
        cin >> x >> y;
        points.push_back(mp(x, y));
    }
    rep(c1,0,n){
        solve(c1);
    }
    cout << ans_string << "\n";
    return 0;
}