^^^^^^^^^^>>vvv>v>vvv<vvv>>
