#!/usr/bin/env python3
import random
dir = ">^"
ans = []

for _ in range(10**6):
    ans.append(dir[random.randrange(0,2)])

print("".join(ans))
