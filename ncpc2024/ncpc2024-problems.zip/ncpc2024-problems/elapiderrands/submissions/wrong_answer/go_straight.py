#!/usr/bin/env python3

xp, yp = (0,0)
n = int(input())

ans = []

for _ in range(n):
    x, y = map(int, input().split())
    while xp < x:
        ans.append('>')
        xp += 1
    while xp > x:
        ans.append('<')
        xp -= 1
    while yp < y:
        ans.append('^')
        yp += 1
    while yp > y:
        ans.append('v')
        yp -= 1

print("".join(ans))
