#include "validator.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(i, a) for(auto& i : a)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

const int MAXX = 10000;
const int MAXD = 20;

void run() {
  int n = Int(1, 20);
  Endl();

  vector<pair<int,int> > points;

  points.push_back({0,0});

  for(int c1 = 0; c1 < n; c1++){
     int a = Int(0, MAXX);
     Space();
     int b = Int(0, MAXX);
     Endl();
     points.push_back({a, b});
  }

  for(int c1 = 0; c1 < n+1; c1++){
    for(int c2 = c1+1; c2 < n+1; c2++){
      int d = abs(points[c1].first - points[c2].first) + abs(points[c1].second - points[c2].second);
      assert(d >= MAXD || n == 2);
    }
  }


}