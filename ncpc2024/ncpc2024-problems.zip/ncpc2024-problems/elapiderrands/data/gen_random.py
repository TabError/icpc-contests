#!/usr/bin/env python3

import sys
import random

def cmdlinearg(name, default=None):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    assert default is not None, name
    return default

MAXN = 20
MAXX = 10000
MAXD = 20

random.seed(int(cmdlinearg('seed', sys.argv[-1])))
n = int(cmdlinearg('n', MAXN))

points = []
while len(points) < n:
    x = random.randint(0, MAXX)
    y = random.randint(0, MAXX)
    fail = False
    for xp, yp in points:
        if abs(xp-x)+abs(yp-y) < MAXD or abs(xp)+abs(yp) < MAXD:
            fail = True
    if not fail:
        points.append((x, y))

print(n)
for (x, y) in points:
    print(x, y)
    