#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution solution.cpp

compile gen_random.py

MAXN=20

for s in {0..99}; do
    tc case-$s gen_random n=$MAXN
done

