#include "validate.h"
#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define trav(a, x) for(auto& a : x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double ld;

int DX[4] = {1,0,-1,0};
int DY[4] = {0,1,0,-1};

int parse(char ch){
  if(ch == '>')return 0;
  if(ch == '^')return 1;
  if(ch == '<')return 2;
  if(ch == 'v')return 3;
  assert(0);
  return -1;
}

int main(int argc, char **argv) {
  init_io(argc, argv);

  int n;
  judge_in >> n;
  map<pii, int> points;
  for(int c1 = 0; c1 < n; c1++){
    int a,b;
    judge_in >> a >> b;
    points[{a, b}] = c1;
  }

  string ANS;
  if(!(author_out >> ANS)){
    wrong_answer("Could not read output");
  }
  int k = ANS.length();
  if(k > 2000000){
    wrong_answer("Too long output %d", k);
  }

  for(int c1 = 0; c1 < k; c1++){
    if(ANS[c1] != '<' && ANS[c1] != '>' && ANS[c1] != 'v' && ANS[c1] != '^'){
      wrong_answer("Invalid char at position %d", c1+1);
    }
  }
  
  int goal = 0;
  set<pii> seen;
  int x = 0;
  int y = 0;
  for(int c1 = 0; c1 < k+1; c1++){
      if(seen.find({x, y}) != seen.end()){
        wrong_answer("Visited point (%d, %d) twice", x, y);
      }
      seen.insert({x, y});
      if(points.find({x, y}) != points.end()){
        int i = points[{x, y}];
        if(i == goal){
          goal++;
        }
        else{
          wrong_answer("Visited point %d too early", i+1);
        }
      }
      if(c1 == k)break;
      int dir = parse(ANS[c1]);
      x += DX[dir];
      y += DY[dir];
  }

  if(goal < n){
    wrong_answer("Only visited the first %d points", goal);
  }

  string trailing;
  if(author_out >> trailing){
    wrong_answer("Trailing output");
  }

  accept();
}
