#!/usr/bin/python3
import sys
import random
import math

def rho(n):
    if n <= 10 ** 10:
        divs = []
        for d in range(1, n):
            if d * d > n:
                break
            if n % d == 0:
                divs.append(d)
                if d * d != n:
                    divs.append(n // d)
        return random.choice(divs)
    for seed in [2, 3, 5, 7, 11, 13, 1031]:
        x, y, d = seed, seed, 1
        while d == 1:
            x = (x * x + 1) % n
            y = (y * y + 1) % n
            y = (y * y + 1) % n
            d = math.gcd(abs(x - y), n)
        if d == n:
            continue
        return d
    return 1

random.seed(int(sys.argv[-1]))
mx = eval(sys.argv[1])
n = random.randint(1, mx)
p = random.randint(1, n)
if n % 2 != p % 2:
    n -= 1
if random.randint(1, 5) == 1:
    p = rho(n)
    if n % 2 != p % 2:
        p *= 2
print(n, p)
