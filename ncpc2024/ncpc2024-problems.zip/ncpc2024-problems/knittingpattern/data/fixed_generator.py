#!/usr/bin/python3
import sys

n = eval(sys.argv[1])
p = eval(sys.argv[2])
print(n, p)
