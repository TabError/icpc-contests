#!/usr/bin/python3
n, p = map(int, input().strip().split())
print(2 * (((n - p) // 2) % p))
