#include<iostream>
using namespace std;

int main() {
    long long n, p; cin >> n >> p;
    if(n % p == 0) cout << 0;
    else {
        long long left = (n - p) / 2;
        volatile int unoptimize = 0;
        while(left >= p) {
            left = left - p;
            unoptimize++;
        }
        cout << 2 * left;
    }
    cout << '\n';
}
