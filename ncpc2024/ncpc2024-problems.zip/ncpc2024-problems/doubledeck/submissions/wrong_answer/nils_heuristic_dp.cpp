#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n,k;
const int big = 1000000007;
const int MAXN = 10001;
const int MAXK = 16;
const int LIM = 20;
vi A,B;

int DP[MAXN*MAXK][2*LIM+1] = {0}; 
bool DPC[MAXN*MAXK][2*LIM+1] = {0}; 

int dp(int i, int j){
    if(max(i,j) == n*k)return 0;
    int d = j-i+LIM;
    if(d < 0 || d > 2*LIM)return -big;
    if(DPC[i][d])return DP[i][d];
    if(A[i] == B[j]){
        DP[i][d] = 1 + dp(i+1,j+1);
    }
    else{
        DP[i][d] = max(dp(i+1,j), dp(i,j+1));
    }
    DPC[i][d] = 1;
    return DP[i][d];
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n >> k;
    rep(c1,0,n*k){
        int a;
        cin >> a;
        A.push_back(a);
    }
    rep(c1,0,n*k){
        int b;
        cin >> b;
        B.push_back(b);
    }

    cout << dp(0,0) << "\n";

    return 0;
}
