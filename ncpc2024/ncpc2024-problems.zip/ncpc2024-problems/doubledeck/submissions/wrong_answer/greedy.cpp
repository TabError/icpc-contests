#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n,k;
const int MAXN = 10001;
const int MAXK = 16;
vi A,B;

int greedy(){
    int i = 0;
    int j = 0;
    int ans = 0;

    while(max(i,j) < n*k){
        if(rand()%2 == 0){
            while(j < n*k && B[j] != A[i]){
                j++;
            }
            if(j == n*k)break;
            i++;
            j++;
            ans++;
        }
        else{
            while(i < n*k && A[i] != B[j]){
                i++;
            }
            if(i == n*k)break;
            j++;
            i++;
            ans++;
        }
    }
    return ans;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n >> k;
    rep(c1,0,n*k){
        int a;
        cin >> a;
        a--;
        A.push_back(a);
    }
    rep(c1,0,n*k){
        int b;
        cin >> b;
        b--;
        B.push_back(b);
    }
    
    const int lim = 100000000;
    int ans = 0;
    rep(_,0,lim/(n*k)){
        ans = max(ans, greedy());
    }

    cout << ans << "\n";

    

    return 0;
}
