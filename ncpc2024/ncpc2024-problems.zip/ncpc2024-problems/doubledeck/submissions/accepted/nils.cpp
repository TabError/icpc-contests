#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

struct Tree {
	typedef int T;
	static constexpr T unit = 0;
	T f(T a, T b) { return max(a, b); } // (any associative fn)
	vector<T> s; int n;
	Tree(int n = 0, T def = unit) : s(2*n, def), n(n) {}
	void update(int pos, T val) {
		for (s[pos += n] = val; pos /= 2;)
			s[pos] = f(s[pos * 2], s[pos * 2 + 1]);
	}
	T query(int b, int e) { // query [b, e)
		T ra = unit, rb = unit;
		for (b += n, e += n; b < e; b /= 2, e /= 2) {
			if (b % 2) ra = f(ra, s[b++]);
			if (e % 2) rb = f(s[--e], rb);
		}
		return f(ra, rb);
	}
};

int n,k;
const int MAXN = 10001;
const int MAXK = 16;
vi A,B;

vector<vi> C(MAXN, vi());


int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n >> k;
    rep(c1,0,n*k){
        int a;
        cin >> a;
        a--;
        A.push_back(a);
    }
    rep(c1,0,n*k){
        int b;
        cin >> b;
        b--;
        B.push_back(b);
    }
    reverse(all(A));
    reverse(all(B));

    for(int c1 = n*k-1; c1 >= 0; c1--){
        C[B[c1]].push_back(c1);
    }

    Tree ST(n*k);
    vi st(n*k, 0);
    int ans = 0;

    rep(i,0,n*k){
        trav(j, C[A[i]]){
            int x = 1 + ST.query(0,j);
            if(x > st[j]){
                ans = max(ans, x);
                st[j] = x;
                ST.update(j, x);
            }
        }
    }

    cout << ans << "\n";

    return 0;
}
