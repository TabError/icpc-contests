#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#define getchar() getchar_unlocked()
#define irep(E, F) for (int E = 0; E < (F); E++)
#define iper(E, F) for (int E = (F) - 1; E >= 0; E--)
#define rep(E, F) for (E = 0; E < (F); E++)
#define per(E, F) for (E = (F) - 1; E >= 0; E--)
typedef long long ll;
int min(int a, int b) { return a < b ? a : b; }
int max(int a, int b) { return a > b ? a : b; }

int get_int()
{
    int r = 0, c = getchar(), s = 1;
    while (c != '-' && (c < '0' || c > '9')) c = getchar();
    while (c == '-') s *= -1, c = getchar();
    while (c >= '0' && c <= '9') r = r*10 + c - '0', c = getchar();
    return s*r;
}

int ft_query(int *t, int x)
{
    int r = 0;
    for (x++; x; x -= (x&-x)) r = max(r, t[x]);
    return r;
}
void ft_update(int *t, int x, int y) { for (x++; x <= t[0]; x += (x&-x)) t[x] = max(t[x], y); }
void ft_init(int *t, int n) { irep(i, n + 1) t[i] = i == 0 ? n : 0; }

int lcs(int *a, int *b, int m, int n, int k)
{
    int i, j, x, y, d[m + 2], e[n][k], ee[n];
    rep(i, n) ee[i] = 0;
    per(i, m) e[b[i]][ee[b[i]]++] = i;
    ft_init(d, m + 1);
    rep(i, m) rep(j, k)
    {
        x = ft_query(d, e[a[i]][j] - 1), y = ft_query(d, e[a[i]][j]);
        if (y < x + 1) ft_update(d, e[a[i]][j], x + 1);
    }
    return ft_query(d, m);
}

int main()
{
    int i, j, n = get_int(), k = get_int(), m;
    m = n*k;
    int a[m], b[m];
    rep(i, m) a[i] = get_int() - 1;
    rep(i, m) b[i] = get_int() - 1;
    printf("%d\n", lcs(a, b, m, n, k));
    return 0;
}
