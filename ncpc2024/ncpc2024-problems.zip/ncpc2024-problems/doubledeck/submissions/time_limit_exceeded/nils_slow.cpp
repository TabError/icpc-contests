#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n,k;
const int MAXN = 10001;
const int MAXK = 16;
vi A,B;

int DP[2][MAXN*MAXK] = {0}; 

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n >> k;
    rep(c1,0,n*k){
        int a;
        cin >> a;
        A.push_back(a);
    }
    rep(c1,0,n*k){
        int b;
        cin >> b;
        B.push_back(b);
    }
    reverse(all(A));
    reverse(all(B));

    rep(i,0,n*k){
        rep(j,0,n*k){
            if(A[i] == B[j]){
                DP[(i+1)%2][j+1] = 1 + DP[i%2][j];
            }
            else{
                DP[(i+1)%2][j+1] = max(DP[i%2][j+1], DP[(i+1)%2][j]);
            }
        }
    }
    cout << DP[(n*k)%2][n*k] << "\n";

    return 0;
}
