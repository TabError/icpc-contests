#include <stdio.h>
#include <assert.h>
#define getchar() getchar_unlocked()
#define irep(E, F) for (int E = 0; E < (F); E++)
#define iper(E, F) for (int E = (F) - 1; E >= 0; E--)
#define rep(E, F) for (E = 0; E < (F); E++)
#define per(E, F) for (E = (F) - 1; E >= 0; E--)
typedef long long ll;
int min(int a, int b) { return a < b ? a : b; }
int max(int a, int b) { return a > b ? a : b; }

int get_int()
{
    int r = 0, c = getchar(), s = 1;
    while (c != '-' && (c < '0' || c > '9')) c = getchar();
    while (c == '-') s *= -1, c = getchar();
    while (c >= '0' && c <= '9') r = r*10 + c - '0', c = getchar();
    return s*r;
}

int main()
{
    int i, j, n = get_int(), k = get_int();
    int m = n*k;
    int a[m], b[m], d[m];
    rep(i, m) a[i] = get_int();
    rep(i, m) b[i] = get_int();
    rep(i, m) d[i] = 0;
    rep(i, m)
    {
        per(j, m) if (a[i] == b[j]) d[j] = max(d[j], (j == 0 ? 0 : d[j - 1]) + 1);
        rep(j, m - 1) d[j + 1] = max(d[j + 1], d[j]);
    }
    printf("%d\n", d[m - 1]);
    return 0;
}
