
n, k = 1000, 15
a = sorted(list(range(1, n + 1))*k)
print(n, k)
print(*a)
#print(*a)
print(*a[::-1])
