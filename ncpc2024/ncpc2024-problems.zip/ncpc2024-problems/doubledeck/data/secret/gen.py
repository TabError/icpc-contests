from random import shuffle

n, k = 10000, 15
a = list(range(1, n + 1))*k
print(n, k)
shuffle(a)
print(*a)
shuffle(a)
print(*a)
