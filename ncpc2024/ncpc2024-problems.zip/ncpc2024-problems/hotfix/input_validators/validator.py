#!/usr/bin/python3
import sys, string

line = sys.stdin.readline()
assert len(line) <= 10 ** 6 + 1
assert line[-1] == '\n'

for c in line[:-1]:
    assert c in string.ascii_letters

assert not sys.stdin.read()
sys.exit(42)
