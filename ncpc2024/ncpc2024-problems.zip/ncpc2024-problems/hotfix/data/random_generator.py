#!/usr/bin/python3
import sys
import random
import string

random.seed(int(sys.argv[-1]))
mxn = int(sys.argv[1])
let = int(sys.argv[2])
n = random.choice([mxn, random.randint(mxn // 2, mxn)])
res = []

for _ in range(n):
    res.append(random.choice(string.ascii_letters[:let]))

print("".join(res))
