#!/usr/bin/python3
import sys

print(sys.argv[1])
