#!/usr/bin/python3
import sys
import random
import string
import itertools

random.seed(int(sys.argv[-1]))
typ = sys.argv[1]

if typ == "sqrt":
    res = []
    for _ in range(1000):
        res.append(random.choice(string.ascii_letters))
    chunk = "".join(res)
    res = [chunk for _ in range(1000)]
    print("".join(res))

if typ == "log":
    res = []
    for _ in range(20):
        res.append(random.choice(string.ascii_letters))
    chunk = "".join(res)
    res = [chunk for _ in range(50000)]
    print("".join(res))

if typ == "nlog":
    res = []
    for _ in range(50000):
        res.append(random.choice(string.ascii_letters))
    chunk = "".join(res)
    res = [chunk for _ in range(20)]
    print("".join(res))

if typ == "all":
    print(string.ascii_letters)

if typ == "superpermutation":
    res = []
    letters = ["X", "Y", "Z", "a", "b", "c", "f", "G"]
    for perm in itertools.permutations(letters):
        res += "".join(perm)
    random.shuffle(res)
    print("".join(res))
