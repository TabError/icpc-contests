#include<bits/stdc++.h>
using namespace std;

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    string s, t = ""; cin >> s;
    map<string,int> occ;
    for(int i = 0; i < s.size(); ++i) {
        t.clear();
        for(int j = i; j < s.size(); ++j) {
            t.push_back(s[j]);
            if(!occ.count(t)) occ[t] = 1;
            else occ[t]++;
        }
    }
    int cnt[256];
    memset(cnt, 0, sizeof(cnt));
    for(auto p : occ) {
        for(char c : p.first)
            cnt[c]++;
        for(char c : to_string(p.second))
            cnt[c]++;
    }
    for(int i = 0; i < 256; ++i) {
        if(cnt[i] == 0) continue;
        cout << ((char) i) << ' ';
        cout << cnt[i] << '\n';
    }
}
