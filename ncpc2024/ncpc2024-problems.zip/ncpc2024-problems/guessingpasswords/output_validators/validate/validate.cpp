#include "validate.h"
#include <vector>
#include <set>
using namespace std;

void toupper_string(string &s){
    for (char& c : s) c = (char)toupper(c);
}

int main(int argc, char **argv) {
    init_io(argc, argv);
    
    int n, m;
    judge_in >> n >> m;

    string s;
    judge_ans >> s;

    if(s == "Bugged!") {
        string t;
        if(!(author_out >> t)) {
            wrong_answer("Failed to read any token from output.\n");
        }

        toupper_string(t);
        if(t != "BUGGED!") {
            wrong_answer("No solution but output is not \"Bugged!\".\n");
        }
        author_out >> ws;
        if(author_out >> t) {
            wrong_answer("Trailing output.\n");
        }
        accept();
    }

    vector<string> colours(n);
    for(int i = 0; i < n; ++i)
        judge_in >> colours[i];
    colours.push_back(string(m, 'X'));

    int sigma;
    judge_in >> sigma;

    vector<vector<int>> answer(n + 1, vector<int>(m));
    for(int i = 0; i <= n; ++i) {
        for(int j = 0; j < m; ++j) {
            if(!(author_out >> answer[i][j])) {
                wrong_answer("Failed to read sufficient number of ints in output.\n");
            }
            if(answer[i][j] <= 0) {
                wrong_answer("Non-positive integer in output.\n");
            }
            if(answer[i][j] > sigma) {
                wrong_answer("Character index out of bounds.\n");
            }
        }
    }
    
    for(int j = 0; j < m; ++j) {
        set<int> column_set;
        for(int i = 0; i <= n; ++i) {
            if(column_set.count(answer[i][j])) {
                wrong_answer("Duplicate value in column %d.\n", j);
            } else {
                column_set.insert(answer[i][j]);
            }
        }
    }

    
    set<int> in_ans, grays, yellows;
    for(int j = 0; j < m; ++j) {
        in_ans.insert(answer.back()[j]);
    }

    for(int i = 0; i <= n; ++i) {
        set<int> in_col;
        for(int j = 0; j < m; ++j) {
            if(in_col.count(answer[i][j])) {
                wrong_answer("Duplicate value in row %d.\n", i);
            }
            if(grays.count(answer[i][j])) {
                wrong_answer("Guess in row %d contradicts earlier clue.\n", i);
            }
            in_col.insert(answer[i][j]);
            if(!in_ans.count(answer[i][j])) {
                grays.insert(answer[i][j]);
                if(colours[i][j] != 'G') {
                    wrong_answer("Wrong colour outcome at index %d, %d.\n", i, j);
                }
            } else if(answer[i][j] == answer.back()[j]) {
                if(colours[i][j] != 'X') {
                    wrong_answer("Wrong colour outcome at index %d, %d.\n", i, j);
                }
            } else {
                yellows.insert(answer[i][j]);
                if(colours[i][j] != 'Y') {
                    wrong_answer("Wrong colour outcome at index %d, %d.\n", i, j);
                }
            }
        }
        for(int x : yellows) {
            if(!in_col.count(x)) {
                wrong_answer("Guess in row %d contradicts earlier clue.\n", i);
            }
        }
    }

    accept();
}
