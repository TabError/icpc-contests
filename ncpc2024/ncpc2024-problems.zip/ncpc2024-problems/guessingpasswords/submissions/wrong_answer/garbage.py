#!/usr/bin/python3

print("garbage")
