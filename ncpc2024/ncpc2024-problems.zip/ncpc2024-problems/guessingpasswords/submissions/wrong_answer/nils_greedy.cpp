#include <bits/stdc++.h>
#include <bits/extc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n,m,k;
const int MAXN = 103;
int grid[MAXN][MAXN];

int ans[MAXN][MAXN];
int now = 1;

vi col_yellows, ind_c;
int row_y = 0;
bool comp_c(int i, int j){
    return col_yellows[i] < col_yellows[j];
}

vi col_deg;
bool comp_2(int i, int j){
    return col_deg[i] > col_deg[j];
}


int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n >> m;

    int greys = 0;
    vi yellows;

    rep(c1,0,m){
        col_yellows.push_back(0);
        ind_c.push_back(c1);
    }

    rep(c1,0,n){
        string s;
        cin >> s;
        int y = 0;
        rep(c2,0,m){
            grid[c1][c2] = (s[c2] == 'Y');
            y += grid[c1][c2];
            greys += (grid[c1][c2] == 0);
            ans[c1][c2] = -1;
            if(grid[c1][c2] == 1){
                col_yellows[c2]++;
                if(c1 == 0)row_y++;
            }
        }
        yellows.push_back(y);
    }

    rep(c2,0,m){
        grid[n][c2] = 0;
        ans[n][c2] = -1;
    }

    sort(all(ind_c), comp_c);
    rep(c1,0,row_y){
        int i = ind_c[c1];
        if(col_yellows[i] >= row_y){
            cout << "Bugged!\n";
            return 0;
        }
        col_yellows[i]++;
        grid[n][i] = 1;
    }
    greys += m-row_y;
    rep(c1,0,m){
        if(col_yellows[c1] > row_y){
            cout << "Bugged!\n";
            return 0;
        }
    }

    yellows.push_back(row_y);
    n++;

    bool fail = 0;

    cin >> k;
    if(greys + yellows.back() > k)fail = 1;

    if(fail){
        cout << "Bugged!\n";
        return 0;
    }

    const int lim1 = 100;

    rep(t1,0,lim1){
        col_deg.clear();
        vi ind;
        now = 1;
        rep(c1,0,n){
            rep(c2,0,m){
                ans[c1][c2] = -1;
            }
        }
        rep(c1,0,m){
            col_deg.push_back(col_yellows[c1]);
            ind.push_back(c1);
        }
        bool yes = 1;
        rep(_,0,row_y){
            sort(all(ind), comp_2);
            vi row_taken(n, 0);
            int match = 0;
            rep(c2,0,m){
                int j = ind[c2];
                vi ind2;
                rep(c1,0,n){
                    ind2.push_back(c1);
                }
                random_shuffle(all(ind2));
                rep(c1,0,n){
                    int i = ind2[c1];
                    if(grid[i][j] == 1 && ans[i][j] == -1 && row_taken[i] == 0){
                        row_taken[i] = 1;
                        match++;
                        ans[i][j] = now;
                        break;
                    }
                }
            }
            if(match != n){
                yes = 0;
                break;
            }
            now++;
        }  
        if(yes)break; 
    }

    rep(c1,0,n){
        rep(c2,0,m){
            if(ans[c1][c2] == -1){
                ans[c1][c2] = now;
                now++;
            }
            cout << ans[c1][c2] << " ";
        }cout << "\n";
    }


    return 0;
}