#include<bits/stdc++.h>
using namespace std;
typedef vector<int> vi;
typedef pair<int,int> ii;
typedef vector<vi> vvi;

void bail(int code) {
    // cerr << code << '\n';
    cout << "Bugged!\n";
    exit(0);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);
    int n, m; cin >> n >> m;
    vector<string> inp(n);
    for(int i = 0; i < n; ++i)
        cin >> inp[i];
    inp.push_back(string(m, 'X')); n++;
    vi gyrow(n, 0), ycol(m, 1);
    int xcnt = 0, sigma; cin >> sigma;
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            if(inp[i][j] == 'G') xcnt++;
            else if(inp[i][j] == 'X') gyrow[i]++;
            else gyrow[i]++, ycol[j]++;
            if(i != n - 1 && (inp[i][j] == 'X') &&
                (inp[i + 1][j] != 'X')) bail(0);
        }
        if(i > 0 && gyrow[i] < gyrow[i - 1]) bail(1);
    }
    if(xcnt + n > sigma) bail(2);
    vvi outp(n, vi(m, -1));
    int cur_char = 0;
    for(int i = n - 1; i >= 0; --i) {
        for(int j = 0; j < m; ++j) {
            if(inp[i][j] != 'X') continue;
            if(i != 0 && inp[i - 1][j] == 'X') continue;
            for(int k = i; k < n; ++k) outp[k][j] = cur_char;
            vi used(m, 0); used[j] = 1;
            for(int k = i - 1; k >= 0; --k) {
                int bst = -1, val = 0;
                for(int l = 0; l < m; ++l) {
                    if(used[l]) continue;
                    if(inp[k][l] != 'Y') continue;
                    if(outp[k][l] != -1) continue;
                    if(ycol[l] > bst) {
                        bst = ycol[l];
                        val = l;
                    }
                }
                if(bst == -1) break;
                ycol[val]--;
                outp[k][val] = cur_char;
                used[val] = 1;
            }
            ycol[j]--;
            /*for(int ii = 0; ii < n; ++ii) {
                for(int jj = 0; jj < m; ++jj) {
                    cerr << outp[ii][jj] + 1 << ' ';
                }
                cerr << '\n';
            }
            for(int ii = 0; ii < m; ++ii) 
                cerr << ycol[ii] << ' ';
            cerr << '\n';
            cerr << '\n';*/
            cur_char++;
        }
    }

    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            if(inp[i][j] != 'G') { if(outp[i][j] == -1) bail(3); }
            else outp[i][j] = cur_char++;
        }
    }
    for(int i = 0; i < n; ++i) {
        for(int j = 0; j < m; ++j) {
            cout << outp[i][j] + 1;
            if(j != m - 1) cout << ' ';
        }
        cout << '\n';
    }
}

