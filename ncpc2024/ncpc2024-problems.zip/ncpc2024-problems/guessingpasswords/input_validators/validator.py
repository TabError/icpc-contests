#!/usr/bin/python3
import re, sys


line = sys.stdin.readline()
assert re.match("^[1-9][0-9]* [1-9][0-9]*\n$", line)
n, m = map(int, line.strip().split())
assert 1 <= n <= 100
assert 1 <= m <= 100

ycount = None

for i in range(n):
    line = sys.stdin.readline()
    assert re.match("^[GY]+\n", line)
    assert len(line.strip()) == m
    if i == 0:
        ycount = line.count('Y')
    else:
        assert line.count('Y') == ycount

line = sys.stdin.readline()
assert re.match("^[1-9][0-9]*\n$", line)
sigma = int(line)
assert 1 <= sigma <= 10**6

assert not sys.stdin.read()
sys.exit(42)
