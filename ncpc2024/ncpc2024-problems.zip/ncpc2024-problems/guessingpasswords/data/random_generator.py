#!/usr/bin/python3
import sys
import random

random.seed(int(sys.argv[-1]))
mx = int(sys.argv[1])
n = random.choice([mx, random.randint(mx // 2, mx)])
m = random.choice([mx, random.randint(mx // 2, mx)])
m = max(n, m)
print(n, m)
yellows = 0
yellow_add = [0 for i in range(n)]
for k in range(m - random.randint(0, 2)):
    yellow_add[random.randint(0, n - 1)] += 1
for i in range(n):
    yellows += yellow_add[i]
    lst = ["Y" for _ in range(yellows)] + ["G" for _ in range(m - yellows)]
    random.shuffle(lst)
    print("".join(lst))
print(mx ** 2)
