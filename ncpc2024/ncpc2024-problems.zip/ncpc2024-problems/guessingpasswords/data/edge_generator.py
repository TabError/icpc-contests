#!/usr/bin/python3
import sys
import random

random.seed(int(sys.argv[-1]))

mx = 100

typ = sys.argv[1]

if typ == "allgray1":
    print(mx, mx)
    for i in range(mx):
        print("G" * mx)
    print(mx ** 2 + mx)

if typ == "allgray0":
    print(mx, mx)
    for i in range(mx):
        print("G" * mx)
    print(mx ** 2 + mx - 1)

if typ[:7] == "yellowp":
    p = int(typ[7:])
    shuf = mx * p // 100
    rows = [mx, random.randint(mx // 2, mx)][int(sys.argv[2])]
    print(rows, mx)
    for i in range(rows):
        lst = ["Y" for _ in range(shuf)]
        while len(lst) < mx:
            lst.append("G")
        random.shuffle(lst)
        print("".join(lst))
    print(mx ** 2 + mx)
