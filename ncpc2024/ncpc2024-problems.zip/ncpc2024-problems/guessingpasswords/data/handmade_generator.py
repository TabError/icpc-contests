#!/usr/bin/python3
import sys
import random

index = int(sys.argv[1])

cases = [
    (["G", "G", "G"], 7),
    (["G"], 1),
    (["G"], 2),
    (["Y"], 1),
    (["GY", "YG"], 2),
    (["YG", "GY"], 3),
    (["GG", "GG", "GG"], 5),
    (["GGY", "GYG", "YGG"], 9),
    (["YYY", "YYY", "YYY"], 9),
    (["GYG", "GYG"], 9),
    (["GYGGY", "YGYGG", "GGYYG", "GYGGY"], 20),
    (["YYGG", "YYGG"], 20),
    (["GGYY", "GGYY"], 20),
    (["GYGY", "GYGY"], 20),
    (["YGYG", "YGYG"], 20),
]

guesses, sigma = cases[index]

print(len(guesses), len(guesses[0]))
for l in guesses:
    print(l)
print(sigma)
