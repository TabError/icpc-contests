#include "validate.h"
#include <vector>
#include <algorithm>
using namespace std;

using int_t = int64_t;

int_t read_user_int() {
    int_t x;
    if(!(author_out >> x)) {
        wrong_answer("Malformed output, failed to read int.\n");
    }
    return x;
}


int main(int argc, char **argv) {
    init_io(argc, argv);
    int_t n;
    judge_in >> n;

    int_t k = read_user_int();
    if (k < 0) {
        wrong_answer("Value of k is negative.\n");
    }
    if (k > n) {
        wrong_answer("Value of k is too large.\n");
    }
    vector<int_t> ans(k);
    for(int i = 0; i < k; ++i) {
        ans[i] = read_user_int();
    }
    string trailing;
    if(author_out >> trailing) {
        wrong_answer("Trailing output.\n");
    }

    int_t number_of_beats = 0;
    for (int_t i = 0; i < k; i++) {
        const auto& x{ ans[i] };
        if (x != 2 && x != 3) {
            wrong_answer("Group %ld's size %ld is invalid.\n", i + 1, x);
        }
        number_of_beats += x;
    }
    if (number_of_beats != n) {
        wrong_answer("Beats in output sum to %ld instead of the desired n = %ld.\n", number_of_beats, n);
    }
    accept();
}
