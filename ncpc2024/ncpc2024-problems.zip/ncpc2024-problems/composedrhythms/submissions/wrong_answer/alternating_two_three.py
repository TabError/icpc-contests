#!/usr/bin/python3
n = int(input())

L = []
while n > 0:
    L.append(2)
    n -= 2
    if n <= 0:
        break
    L.append(3)
    n -= 3

print(len(L))
print(' '.join(map(str, L)))
