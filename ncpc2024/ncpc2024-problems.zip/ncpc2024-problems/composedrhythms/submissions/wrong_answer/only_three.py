#!/usr/bin/python3
n = int(input())

L = []
while n > 0:
    L.append(3)
    n -= 3

print(len(L))
print(' '.join(map(str, L)))
