#!/usr/bin/python3
from random import choice
n = int(input())

L = []
while n > 0:
    x = choice([2, 3])
    L.append(x)
    n -= x

print(len(L))
print(' '.join(map(str, L)))
