#include <iostream>
using namespace std;

int main()
{
    int x = 0, y, n;
    
    cin >> n;

    while (n != 0) {
        if (n == 2 || n == 4) {
            y = n / 2;
            n = 0;
        }
        else {
            n = n - 3;
            x++;
        }
    }

    cout << 10*n + x + y << endl;

    for (int i = 0; i < x; i++)
        cout << 3 << " ";

    if(y > 0)
     cout << 2;

    for (int i = 0; i < y - 1; i++)
        cout << " " << 2;

    return 0;
}
