#include <iostream>
#include <vector>

using namespace std;

int main() {
    int32_t n;
    cin >> n;
    
    vector<int32_t> result;
    while (n % 2 != 0) {
        n -= 3;
        result.push_back(3);
    }
    while (n > 0) {
        n -= 2;
        result.push_back(2);
    }
    cout << size(result) << endl;
    for (const auto x : result) {
        cout << x << " ";
    }
    cout << endl;
    return 0;
}
