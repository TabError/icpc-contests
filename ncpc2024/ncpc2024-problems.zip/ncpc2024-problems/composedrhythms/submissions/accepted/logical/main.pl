[kattio].

main :- read_int(N), solve(N, L), length(L, K), write(K), nl, output(L), nl.

output([]).
output([X]) :- write(X).
output([X|T]) :- output(T), write(" "), write(X).

solve(2, [2]).
solve(3, [3]).
solve(N, [X|L]) :- 
    N > 1
->  (   N3 is N - 3,
        solve(N3, L),
        X is 3
    ;   N2 is N - 2,
        solve(N2, L),
        X is 2
    ).
