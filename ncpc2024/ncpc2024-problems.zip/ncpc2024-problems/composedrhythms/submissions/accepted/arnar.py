#!/usr/bin/python3
n = int(input())

L = []
while n:
    if n == 3:
        L.append(3)
        n -= 3
    else:
        L.append(2)
        n -= 2

print(len(L))
print(' '.join(map(str, L)))
