#!/usr/bin/python3

n = int(input())
beats = [2]*(n//2)
beats[0] += n%2
print(len(beats))
print(*beats)
