#!/usr/bin/python3
def works(n):
    if n < 4:
        return n == 2 or n == 3
    return works(n-2) or works(n-3)

n = int(input())

L = []
while n:
    if works(n-2):
        L.append(2)
    elif works(n-3):
        L.append(3)
    else:
        assert False

print(len(L))
print(' '.join(map(str, L)))
