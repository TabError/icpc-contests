#include <numeric>
#include <iostream>
#include <vector>

using namespace std;

int main() {
    int32_t n;
    cin >> n;
    
    vector<int32_t> result;
    while (true) {
        int32_t sum{ accumulate(cbegin(result), cend(result), 0) };
        if (sum == n) {
            break;
        }
        if (sum + 3 == n) {
            result.push_back(3);
        }
        else {
            result.push_back(2);
        }
    }
    cout << size(result) << endl;
    for (const auto x : result) {
        cout << x << " ";
    }
    cout << endl;
    return 0;
}
