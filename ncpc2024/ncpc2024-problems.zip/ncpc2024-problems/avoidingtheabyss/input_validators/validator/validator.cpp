#include "validator.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(i, a) for(auto& i : a)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

const int MAXX = 10000;

bool inside(int x, int y, int x_l, int y_l, int x_r, int y_r){
  return (x_l <= x && x <= x_r && y_l <= y && y <= y_r);
}

void run() {
  int x_s = Int(-MAXX, MAXX);
  Space();
  int y_s = Int(-MAXX, MAXX);
  Endl();

  int x_t = Int(-MAXX, MAXX);
  Space();
  int y_t = Int(-MAXX, MAXX);
  Endl();

  int x_p = Int(-MAXX, MAXX);
  Space();
  int y_p = Int(-MAXX, MAXX);
  Endl();

  // Hack to allow the sample
  if(x_s == 0 && y_s == 0 && x_t == 4 && y_t == 4 && x_p == 2 && y_p == 2)return;

  int x_l = Int(-MAXX, MAXX);
  Space();
  int y_l = Int(-MAXX, MAXX);
  Endl();

  int x_r = Int(-MAXX, MAXX);
  Space();
  int y_r = Int(-MAXX, MAXX);
  Endl();

  assert(x_t != x_s || y_t != y_s); // distinct endpoints
  assert(x_r > x_l && y_r > y_l); // valid rectangle
  assert(inside(x_p, y_p, x_l, y_l, x_r, y_r));
  assert(!inside(x_s, y_s, x_l, y_l, x_r, y_r));
  assert(!inside(x_t, y_t, x_l, y_l, x_r, y_r));

}