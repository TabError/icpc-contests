#!/usr/bin/env python3

import sys
import random

def cmdlinearg(name, default=None):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    assert default is not None, name
    return default

def point_outside():
    x = random.randint(-MAXX, MAXX)
    y = random.randint(-MAXX, MAXX)
    while (x_l <= x <= x_r) and (y_l <= y <= y_r):
        x = random.randint(-MAXX, MAXX)
        y = random.randint(-MAXX, MAXX)
    return (x, y)

MAXX = 10**4

random.seed(int(cmdlinearg('seed', sys.argv[-1])))
x_s = int(cmdlinearg('x_s', MAXX+1))
y_s = int(cmdlinearg('y_s', MAXX+1))

x_t = int(cmdlinearg('x_t', MAXX+1))
y_t = int(cmdlinearg('y_t', MAXX+1))

x_p = int(cmdlinearg('x_p', MAXX+1))
y_p = int(cmdlinearg('y_p', MAXX+1))

x_l = int(cmdlinearg('x_l', MAXX+1))
y_l = int(cmdlinearg('y_l', MAXX+1))

x_r = int(cmdlinearg('x_r', MAXX+1))
y_r = int(cmdlinearg('y_r', MAXX+1))

mode = cmdlinearg('mode', 'fixed')

if mode == "fixed":
    pass
elif mode == "random":
    x_l = random.randint(-MAXX, MAXX)
    y_l = random.randint(-MAXX, MAXX)
    x_r = random.randint(x_l+1, MAXX)
    y_r = random.randint(y_l+1, MAXX)
    x_p = random.randint(x_l, x_r)
    y_p = random.randint(y_l, y_r)

    # hopefully distinct:
    x_s, y_s = point_outside()
    x_t, y_t = point_outside()

print(x_s, y_s)
print(x_t, y_t)
print(x_p, y_p)
print(x_l, y_l)
print(x_r, y_r)
