#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution nils.py

compile gen.py


MAXX=10000

tc random-01 gen mode=random
tc random-02 gen mode=random
tc random-03 gen mode=random
tc random-04 gen mode=random
tc random-05 gen mode=random
tc random-06 gen mode=random
tc random-07 gen mode=random
tc random-08 gen mode=random
tc random-09 gen mode=random
tc random-10 gen mode=random

tc big-01 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=0 y_s=-10000 x_t=0 y_t=10000 x_p=0 y_p=0
tc big-02 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=0 y_s=-10000 x_t=0 y_t=10000 x_p=-10000 y_p=0
tc big-03 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=0 y_s=-10000 x_t=0 y_t=10000 x_p=-10000 y_p=9999
tc big-04 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=0 y_s=-10000 x_t=0 y_t=10000 x_p=-10000 y_p=-9999
tc big-05 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=0 y_s=-10000 x_t=0 y_t=10000 x_p=10000 y_p=-9999
tc big-06 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=0 y_s=-10000 x_t=0 y_t=10000 x_p=10000 y_p=9999
tc big-07 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=-10000 y_s=-10000 x_t=-10000 y_t=10000 x_p=10000 y_p=0
tc big-08 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=10000 y_s=-10000 x_t=10000 y_t=10000 x_p=-10000 y_p=0
tc big-09 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=-10000 y_s=-10000 x_t=10000 y_t=10000 x_p=0 y_p=0
tc big-10 gen x_l=-10000 y_l=-9999 x_r=10000 y_r=9999 x_s=10000 y_s=10000 x_t=-10000 y_t=-10000 x_p=-10000 y_p=-9999

tc long-01 gen x_l=0 y_l=-10000 x_r=1 y_r=10000 x_s=-1 y_s=0 x_t=2 y_t=0 x_p=0 y_p=0
tc long-02 gen x_l=0 y_l=-10000 x_r=1 y_r=10000 x_s=-10000 y_s=0 x_t=10000 y_t=0 x_p=0 y_p=-10000
tc long-03 gen x_l=0 y_l=-10000 x_r=1 y_r=10000 x_s=-1 y_s=0 x_t=2 y_t=0 x_p=0 y_p=10000

tc corner-01 gen x_l=-10000 y_l=-10000 x_r=9999 y_r=9999 x_p=-10000 y_p=-10000 x_s=9998 y_s=10000 x_t=10000 y_t=9998
