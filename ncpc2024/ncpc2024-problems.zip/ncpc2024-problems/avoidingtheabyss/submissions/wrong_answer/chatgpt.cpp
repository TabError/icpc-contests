#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    
    ll x_s, y_s, x_t, y_t, x_p, y_p;
    cin >> x_s >> y_s;
    cin >> x_t >> y_t;
    cin >> x_p >> y_p;
    
    // Check if start and target are on the same side relative to the pool
    bool same_side_x = (x_s < x_p && x_t < x_p) || (x_s > x_p && x_t > x_p);
    bool same_side_y = (y_s < y_p && y_t < y_p) || (y_s > y_p && y_t > y_p);
    
    if(same_side_x || same_side_y){
        // No detour needed, go straight
        cout << "0\n";
    }
    else{
        // Detour to the right of the pool
        const ll OFFSET = 100000; // Sufficiently large to avoid the pool
        // Define two waypoints
        ll detour_x = x_p + OFFSET;
        // Ensure that detour_x does not cause integer overflow
        if(detour_x > 1e9) detour_x = 1e9;
        // Waypoint 1: (detour_x, y_s)
        // Waypoint 2: (detour_x, y_t)
        cout << "2\n";
        cout << detour_x << " " << y_s << "\n";
        cout << detour_x << " " << y_t << "\n";
    }
}
