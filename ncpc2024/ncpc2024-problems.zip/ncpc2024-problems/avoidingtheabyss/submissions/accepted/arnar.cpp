#include <array>
#include <iostream>
#include <vector>

using namespace std;
using int_t = int32_t;

template<typename T>
int sign(const T a) {
    return (a > 0) - (a < 0);
}

struct point_t {
    int_t x, y;
};

point_t get_dir_away_from(const point_t p, const point_t q) {
    return { sign(p.x - q.x), sign(p.y - q.y) };
}


int_t lo = -10001, hi = 10001;
point_t get_first_point(const point_t p, const point_t q) {
    point_t dir = get_dir_away_from(p, q);
    point_t res{ array<int_t, 3>{lo, p.x, hi}[dir.x + 1],
                 array<int_t, 3>{lo, p.y, hi}[dir.y + 1] };
    return res;
}

point_t get_next_point(const point_t p) {
    if (p.x == lo && p.y < hi) {
        return {lo, hi};
    }
    if (p.y == hi && p.x < hi) {
        return {hi, hi};
    }
    if (p.x == hi && p.y > lo) {
        return {hi, lo};
    }
    if (p.y == lo && p.x > lo) {
        return {lo, lo};
    }
    __builtin_unreachable();
    return p;
}

bool can_reach(const point_t p, const point_t q) {
    return (p.x == q.x && (p.x == lo || p.x == hi)) || (p.y == q.y && (p.y == lo || p.y == hi));
}

int main() {
    point_t start, end, pool;
    cin >> start.x >> start.y >> end.x >> end.y >> pool.x >> pool.y;
    
    point_t p1 = get_first_point(start, pool);
    point_t pn = get_first_point(end, pool);
    
    vector<point_t> result;
    result.push_back(p1);
    while (!can_reach(result.back(), pn)) {
        result.push_back(get_next_point(result.back()));
    }
    result.push_back(pn);

    cout << ssize(result) << endl;
    for (auto [x, y] : result) {
        cout << x << " " << y << endl;
    }
    return 0;
}   
