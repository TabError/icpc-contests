#!/usr/bin/env python3

def find_point(x,y):
    if x_p <= x and y_p <= y:
        return 0
    if x_p >= x and y_p <= y:
        return 1
    if x_p >= x and y_p >= y:
        return 2
    return 3

x_s, y_s = map(int, input().split())
x_t, y_t = map(int, input().split())
x_p, y_p = map(int, input().split())

inf = 10**5

square = [(inf, inf), (-inf, inf), (-inf, -inf), (inf, -inf)]

ans = []
i = find_point(x_s, y_s)
j = find_point(x_t, y_t)

ans.append(square[i])
while i != j:
    i += 1
    i %= 4
    ans.append(square[i])

ans.append(ans[-1])
print(len(ans))

for (x, y) in ans:
    print(x, y)
