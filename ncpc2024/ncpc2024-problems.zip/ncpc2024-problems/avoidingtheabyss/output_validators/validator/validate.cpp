#include "validate.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double ld;

// ----Geometry stuff from KACTL----
template <class T> int sgn(T x) { return (x > 0) - (x < 0); }
template<class T>
struct Point {
	typedef Point P;
	T x, y;
	explicit Point(T x=0, T y=0) : x(x), y(y) {}
	bool operator<(P p) const { return tie(x,y) < tie(p.x,p.y); }
	bool operator==(P p) const { return tie(x,y)==tie(p.x,p.y); }
	P operator+(P p) const { return P(x+p.x, y+p.y); }
	P operator-(P p) const { return P(x-p.x, y-p.y); }
	P operator*(T d) const { return P(x*d, y*d); }
	P operator/(T d) const { return P(x/d, y/d); }
	T dot(P p) const { return x*p.x + y*p.y; }
	T cross(P p) const { return x*p.y - y*p.x; }
	T cross(P a, P b) const { return (a-*this).cross(b-*this); }
	T dist2() const { return x*x + y*y; }
	double dist() const { return sqrt((double)dist2()); }
	// angle to x-axis in interval [-pi, pi]
	double angle() const { return atan2(y, x); }
	P unit() const { return *this/dist(); } // makes dist()=1
	P perp() const { return P(-y, x); } // rotates +90 degrees
	P normal() const { return perp().unit(); }
	// returns point rotated 'a' radians ccw around the origin
	P rotate(double a) const {
		return P(x*cos(a)-y*sin(a),x*sin(a)+y*cos(a)); }
	friend ostream& operator<<(ostream& os, P p) {
		return os << "(" << p.x << "," << p.y << ")"; }
};

template<class P> bool onSegment(P s, P e, P p) {
	return p.cross(s, e) == 0 && (s - p).dot(e - p) <= 0;
}

template<class P> vector<P> segInter(P a, P b, P c, P d) {
	auto oa = c.cross(d, a), ob = c.cross(d, b),
	     oc = a.cross(b, c), od = a.cross(b, d);
	// Checks if intersection is single non-endpoint point.
	if (sgn(oa) * sgn(ob) < 0 && sgn(oc) * sgn(od) < 0)
		return {(a * ob - b * oa) / (ob - oa)};
	set<P> s;
	if (onSegment(c, d, a)) s.insert(a);
	if (onSegment(c, d, b)) s.insert(b);
	if (onSegment(a, b, c)) s.insert(c);
	if (onSegment(a, b, d)) s.insert(d);
	return {all(s)};
}

// -------

bool intersect(ll x1, ll y1, ll x2, ll y2, ll x_l, ll y_l, ll x_r, ll y_r){
    vector<Point<ll> > poly = {Point<ll>(x_l,y_l),Point<ll>(x_r,y_l),Point<ll>(x_r,y_r),Point<ll>(x_l,y_r)};
    Point<ll> p1(x1, y1);
	Point<ll> p2(x2, y2);
	
	for(int i = 0; i < 4; i++){
		if(segInter<Point<ll>>(p1, p2, poly[i], poly[(i+1)%4]).size() > 0){
			return 1;
		}
	}
	return 0;
}

ll inf = 1000000000;

int main(int argc, char **argv) {
	init_io(argc, argv);

	ll x_s, y_s, x_t, y_t, x_p, y_p, x_l, y_l, x_r, y_r;

  	judge_in >> x_s >> y_s;
    judge_in >> x_t >> y_t;
    judge_in >> x_p >> y_p;

	if(x_s == 0 && y_s == 0 && x_t == 4 && y_t == 4 && x_p == 2 && y_p == 2){
		// Hack to make the sample work
		x_l = 1;
		y_l = -1;
		x_r = 5;
		y_r = 3;
	}
	else{
    	judge_in >> x_l >> y_l;
    	judge_in >> x_r >> y_r;
	}
    
    cout << x_s << " " << y_s << endl;
    cout << x_t << " " << y_t << endl;
    cout << x_p << " " << y_p << endl;

    int n;

    if(!(cin >> n)){
        wrong_answer("Could not read N");
    }

    if(n < 0 || n > 10){
        wrong_answer("n out of range");
    }

    vector<ll> X,Y;
    X.push_back(x_s);
    Y.push_back(y_s);
    for(int i = 0; i < n; i++){
        ll x,y;
        if(!(cin >> x >> y)){
            wrong_answer("Could not read %dth line", i+1);
        }
        if(x < -inf || x > inf || y < -inf || y > inf){
            wrong_answer("Out of bounds");
        }
        X.push_back(x);
        Y.push_back(y);
    }
    X.push_back(x_t);
    Y.push_back(y_t);

    for(int i = 0; i < int(X.size())-1; i++){
        if(intersect(X[i], Y[i], X[i+1], Y[i+1], x_l, y_l, x_r, y_r)){
            wrong_answer("Intersection! Between (%d, %d) and (%d, %d)", int(X[i]), int(Y[i]),int(X[i+1]),int(Y[i+1]));
        }
    }

	string trailing;
	if(cin >> trailing){
		wrong_answer("Trailing output");
	}

  	accept();
}

