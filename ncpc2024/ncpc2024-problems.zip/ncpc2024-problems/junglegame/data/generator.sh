#!/bin/bash
USE_SCORING=0
. ../../../testdata_tools/gen.sh

# ulimit -s unlimited

use_solution nils.cpp

compile gen_random.py


MAXN=10000

sample_manual 1
sample_manual 2

tc small-01 gen_random n=2
tc small-02 gen_random n=3
tc small-03 gen_random n=1
tc small-04 gen_random n=4
tc small-05 gen_random n=5
tc small-06 gen_random n=5

tc random-01 gen_random n=$MAXN
tc random-02 gen_random n=$MAXN
tc random-03 gen_random n=$MAXN
tc random-04 gen_random n=$MAXN
tc random-05 gen_random n=$MAXN

tc_manual ../manual_tests/one.in
tc_manual ../manual_tests/anti_greedy.in

tc even-01 gen_random n=$MAXN mode=even_permutation
tc even-02 gen_random n=$MAXN mode=even_permutation
tc even-03 gen_random n=$MAXN mode=even_permutation
tc even-04 gen_random n=$MAXN mode=even_identity
tc even-05 gen_random n=$MAXN mode=even_reverse
tc even-06 gen_random n=$MAXN mode=even_row
tc even-07 gen_random n=$(($MAXN-1)) mode=even_row

tc triangle-01 gen_random n=$MAXN mode=triangle
tc row-01 gen_random n=$MAXN mode=row_n
tc anti_greedy-01 gen_random n=5 mode=anti_greedy
tc anti_greedy-02 gen_random n=3 mode=anti_greedy
tc anti_greedy-03 gen_random n=7 mode=anti_greedy
tc anti_greedy-04 gen_random n=999 mode=anti_greedy

tc middle-01 gen_random n=$MAXN mode=middle
tc middle-02 gen_random n=$MAXN mode=middle r=1.1
tc middle-03 gen_random n=$MAXN mode=middle r=2.0
tc middle-04 gen_random n=$MAXN mode=middle r=3.0
tc middle-05 gen_random n=$MAXN mode=middle r=10.0
tc middle-06 gen_random n=$MAXN mode=tri r=1.0
tc middle-07 gen_random n=$MAXN mode=tri r=0.5

tc even-08 gen_random n=$MAXN mode=even_permutation
tc even-09 gen_random n=$MAXN mode=even_permutation
tc even-10 gen_random n=$MAXN mode=even_permutation
tc even-11 gen_random n=$MAXN mode=even_permutation
tc even-12 gen_random n=$MAXN mode=even_permutation
tc even-13 gen_random n=$MAXN mode=even_permutation
