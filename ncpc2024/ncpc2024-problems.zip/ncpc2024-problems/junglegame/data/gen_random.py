#!/usr/bin/env python3

import sys
import random

def cmdlinearg(name, default=None):
    for arg in sys.argv:
        if arg.startswith(name + "="):
            return arg.split("=")[1]
    assert default is not None, name
    return default

MAXN = 2000

random.seed(int(cmdlinearg('seed', sys.argv[-1])))
n = int(cmdlinearg('n', MAXN))
mode = cmdlinearg('mode', 'random')
r = float(cmdlinearg('r', 1.0))

banned = set()
banned_list = []

if mode == "random":
    for _ in range(n):
        x = random.randint(1, 2*n)
        y = random.randint(1, 2*n)
        while (x, y) in banned:
            x = random.randint(1, 2*n)
            y = random.randint(1, 2*n)
        banned.add((x, y))
        banned_list.append((x, y))

elif mode == "even_permutation":
    x = list(range(2,2*n+2,2))
    y = list(range(2,2*n+2,2))
    random.shuffle(x)
    random.shuffle(y)
    for i in range(n):
        banned.add((x[i], y[i]))
        banned_list.append((x[i], y[i]))

elif mode == "even_identity":
    x = list(range(2,2*n+2,2))
    y = list(range(2,2*n+2,2))
    for i in range(n):
        banned.add((x[i], y[i]))
        banned_list.append((x[i], y[i]))

elif mode == "even_reverse":
    x = list(range(2,2*n+2,2))
    y = list(range(2,2*n+2,2))[::-1]
    for i in range(n):
        banned.add((x[i], y[i]))
        banned_list.append((x[i], y[i]))

elif mode == "triangle":
    all_pairs = []
    lim = int(4*(n**(0.5))+10)
    lim = min(lim, 2*n+1)
    for i in range(2,lim):
        for j in range(2,lim):
            all_pairs.append((i+j,(i,j)))
    all_pairs.sort()
    for i in range(n):
        banned.add(all_pairs[i][1])
        banned_list.append(all_pairs[i][1])

elif mode == "row_n":
    row = list(range(2,2*n+1))
    random.shuffle(row)
    for i in range(n):
        banned.add((n, row[i]))
        banned_list.append((n, row[i]))

elif mode == "anti_greedy":
    for i in range(2,n+3,2):
        banned_list.append((i, n+1))
        if i != n+1:
            banned_list.append((n+1, i))
    random.shuffle(banned_list)

elif mode == "middle":
    d = int(r*(n**(0.5)) / 2)+1
    lo = n-d
    hi = n+d
    all_pairs = []
    for i in range(lo,hi+1):
        for j in range(lo,hi+1):
            all_pairs.append((i, j))
    random.shuffle(all_pairs)
    for i in range(n):
        banned_list.append(all_pairs[i])

elif mode == "even_row":
    for i in range(2,2*n+2,2):
        banned_list.append((n+n%2, i))

elif mode == "tri":
    for _ in range(n):
        x = int(random.triangular(2+n-r*n, n+r*n))
        y = int(random.triangular(2+n-r*n, n+r*n))
        while (x, y) in banned:
            x = int(random.triangular(2+n-r*n, n+r*n))
            y = int(random.triangular(2+n-r*n, n+r*n))
        banned.add((x, y))
        banned_list.append((x, y))

print(n)
for i in range(n):
    print(*banned_list[i])
