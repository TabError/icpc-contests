#include "validator.h"

#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(i, a) for(auto& i : a)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;

const int MAXN = 10000;

void run() {
  int n = Int(1, MAXN);
  Endl();

  set<pii> S;
  for(int c1 = 0; c1 < n; c1++){
    int x = Int(2, 2*n);
    Space();
    int y = Int(2, 2*n);
    Endl();
    assert(S.find({x, y}) == S.end());
    S.insert({x, y});
  }

}