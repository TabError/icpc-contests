#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 10003;

bool banned[2*MAXN][2*MAXN] = {0};
vector<pii> B;

set<pii> VS;
vector<pii> V;

bool check(int vx, int vy){
    if(banned[2*vx][2*vy])return 0;
    trav(p, V){
        if(banned[p.first+vx][p.second+vy])return 0;
    }
    return 1;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n;

    rep(c1,0,n){
        int a,b;
        cin >> a >> b;
        banned[a][b] = 1;
        B.push_back({a, b});
    }

    int runs = 5;
    rep(c4,0,runs){
        V.clear();
        VS.clear();
        int lim = 1000000;
        rep(c5,0,lim){
            if(sz(V) == n)break;
            int x = rand()%n+1;
            int y = rand()%n+1;
            pii p = {x,y};
            if(VS.find(p) != VS.end())continue;
            if(check(x,y)){
                VS.insert({x, y});
                V.push_back({x, y});
            }
        }

        if(sz(V) == n){
            cout << "YES\n";
            trav(p, V){
                cout << p.first << " " << p.second << "\n";
            }
            return 0;
        }
    }

    cout << "NO\n";

    return 0;
}