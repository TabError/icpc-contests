#!/usr/bin/python3

n = int(input())
ban = [tuple(map(int, input().strip().split())) for _ in range(n)]

if n == 1 and ban[0] == (2, 2):
    print("NO")
    exit(0)

print("YES")

by_row = [[] for _ in range(2 * n + 1)]
by_col = [[] for _ in range(2 * n + 1)]

for i in range(n):
    by_row[ban[i][0]].append(ban[i][1])
    by_col[ban[i][1]].append(ban[i][0])

for i in range(2, 2 * n + 1, 2):
    if len(by_row[i]) == 0:
        for j in range(1, n + 1):
            print(i // 2, j)
        exit(0)
    if len(by_col[i]) == 0:
        for j in range(1, n + 1):
            print(j, i // 2)
        exit(0)

x1, x2 = -1, -1
for i in range(2, 2 * n + 1, 2):
    if n % 2 == 0 or by_row[i][0] != n + 1:
        if x1 == -1:
            x1 = i
        else:
            x2 = i
        if x2 != -1:
            break

l1, l2 = (n + 1) // 2, n // 2
st1, vl1 = 1, 1
st2, vl2 = 1, 1

if by_row[x1][0] <= n:
    st1, vl1 = n, -1
if by_row[x2][0] <= n:
    st2, vl2 = n, -1

for i in range(l1):
    print(x1 // 2, st1)
    st1 += vl1
for i in range(l2):
    print(x2 // 2, st2)
    st2 += vl2
