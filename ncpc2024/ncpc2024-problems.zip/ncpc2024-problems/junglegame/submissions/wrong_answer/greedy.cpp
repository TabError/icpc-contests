#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

int n;
const int MAXN = 2003;

bool banned[2*MAXN][2*MAXN] = {0};

vector<pii> V;

bool can_add(pii p){
    if(banned[2*p.first][2*p.second])return 0;
    trav(q, V){
        if(banned[p.first+q.first][p.second+q.second])return 0;
    }
    return 1;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> n;

    rep(c1,0,n){
        int a,b;
        cin >> a >> b;
        banned[a][b] = 1;
    }

    rep(x,1,n+1){
        if(sz(V) >= n)break;
        rep(y,1,n+1){
            if(can_add({x, y})){
                V.push_back({x, y});
            }
        }
    }

    if(sz(V) < n){
        cout << "NO\n";
    }
    else{
        cout << "YES\n";
        rep(c1,0,n){
            cout << V[c1].first << " " << V[c1].second << "\n";
        }
    }

    return 0;
}