#!/usr/bin/env python3
import random

n = int(input())
if n == 1:
    print("NO")
else:
    print("YES")
    ans_set = set()
    for i in range(n):
        x = random.randint(1,n)
        y = random.randint(1,n)
        while (x, y) in ans_set:
            x = random.randint(1,n)
            y = random.randint(1,n)
        print(x, y)
        ans_set.add((x, y))
        