#include "validate.h"
#include <bits/stdc++.h>
using namespace std;

#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define trav(a, x) for(auto& a : x)
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef long double ld;

const int MAXN = 2000;

void toupper_string(string &s){
    for (char& c : s) c = (char)toupper(c);
}

int main(int argc, char **argv) {
  init_io(argc, argv);

  int n;
  judge_in >> n;

  set<pii> banned;
  for(int c1 = 0; c1 < n; c1++){
    int a,b;
    judge_in >> a >> b;
    banned.insert({a, b});
  }

  string ans_contestant, ans_judge;

  judge_ans >> ans_judge;
  if(!(author_out >> ans_contestant)){
    wrong_answer("Could not read first string");
  }

  toupper_string(ans_contestant);
  toupper_string(ans_judge);

  if(ans_contestant != "YES" && ans_contestant != "NO"){
    wrong_answer("First string not YES or NO");
  }

  if(ans_contestant == "NO"){
    if(ans_judge == "YES"){
      wrong_answer("Contestant says NO but judge says YES");
    }
  }
  else{
    set<pii> V;
    for(int c1 = 0; c1 < n; c1++){
      int x,y;
      if(!(author_out >> x >> y)){
        wrong_answer("Could not read %dth line", c1+1);
      }
      if(x < 1 || y < 1 || x > n || y > n){
        wrong_answer("Vector out of bounds (%d, %d), line %d", x, y, c1+1);
      }
      if(V.find({x, y}) != V.end()){
        wrong_answer("Duplicate vector (%d, %d), line %d", x, y, c1+1);
      }
      V.insert({x, y});
    }

    trav(p1, V){
      trav(p2, V){
        pii p3 = {p1.first+p2.first, p1.second+p2.second};
        if(banned.find(p3) != banned.end()){
          wrong_answer("Hit banned point (%d, %d)", p3.first, p3.second);
        }
      }
    }

    if(ans_judge == "NO"){
      judge_error("Judge said no, but contestant found solution");
    }
  }

  string trailing;
  if(author_out >> trailing){
    wrong_answer("Trailing output");
  }

  accept();
}
