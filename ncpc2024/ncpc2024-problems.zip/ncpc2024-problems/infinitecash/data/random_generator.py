#!/usr/bin/python3
import sys
import random

random.seed(int(sys.argv[-1]))
salary = 2 ** random.randint(5, 999) + random.randint(-4, 16)
money = random.randint(1, 2 ** 1000 - 1)

targ = len("{:b}".format(salary))
days = targ + random.randint(-4, 16)

print("{:b}".format(salary))
print("{:b}".format(days))
print("{:b}".format(money))
