#!/usr/bin/python3
import sys

print("{:b}".format(eval(sys.argv[1])))
print("{:b}".format(eval(sys.argv[2])))
print("{:b}".format(eval(sys.argv[3])))
