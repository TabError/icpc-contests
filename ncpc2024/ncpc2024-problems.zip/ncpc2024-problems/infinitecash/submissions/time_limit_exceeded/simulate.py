#!/usr/bin/python3

def print_bin(x):
    print("{:b}".format(x))
    exit(0)

s = int(input(), 2)
d = int(input(), 2)
m = int(input(), 2)

days = 0

while True:
    if m == 0:
        print_bin(days)
    m //= 2
    days += 1
    if days % d == 0:
        m += s

