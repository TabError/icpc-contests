#include <bits/stdc++.h>
using namespace std;
 
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define trav(a, x) for(auto& a : x)
#define all(x) x.begin(), x.end()
#define sz(x) (int)(x).size()
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
typedef vector<int> vi;
typedef vector<ll> vl;
typedef long double ld;

const int MAXN = 1001;

string money, extra, d_str;
int d;

int s_to_int(string s){
    int res = 0;
    trav(ch, s){
        res *= 2;
        res += ch-'0';
    }
    return res;
}

string int_to_s(int x){
    string res = "";
    string s01 = "01";
    while(x > 0){
        res += s01[x%2];
        x /= 2;
    }
    reverse(all(res));
    return res;
}

string add(string s1, string s2){
    int carry = 0;
    string s01 = "01";
    reverse(all(s1));
    reverse(all(s2));
    if(sz(s1) > sz(s2))swap(s1,s2);
    while(sz(s1) < sz(s2)){
        s1 += "0";
    }
    string res = "";
    rep(c1,0,sz(s1)){
        int tot = carry + (s1[c1]-'0') + (s2[c1]-'0');
        res += s01[tot%2];
        carry = tot / 2;
    }
    if(carry == 1){
        res += '1';
    }
    reverse(all(res));
    return res;
}

int main() {
    ios_base::sync_with_stdio(0);
    cin.tie(0);
    
    cin >> extra >> d_str >> money;
    if(sz(d_str) > 30){
        cout << int_to_s(sz(money)) << "\n";
        return 0;
    }
    d = s_to_int(d_str);

    int t = 0;

    rep(_,0,MAXN+3){
        if(sz(money) < d){
            cout << int_to_s(sz(money)+t) << "\n";
            return 0;
        }
        money = money.substr(0, sz(money)-d);
        money = add(money, extra);
        t += d;
    }

    cout << "Infinite money!\n";

    return 0;
}