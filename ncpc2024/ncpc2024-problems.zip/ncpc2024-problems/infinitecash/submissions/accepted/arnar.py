#!/usr/bin/python3

MAX_ITERATIONS = 10**6

s = int(input(), base=2)
d = int(input(), base=2)
m = int(input(), base=2)

own = m
day = 0

while own > 0 and day < MAX_ITERATIONS:
    own = own // 2
    if day % d == d - 1:
        own += s
    day += 1

if own == 0:
    print(bin(day)[2:])
else:
    print("Infinite money!")
