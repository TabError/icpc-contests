#!/usr/bin/python3

s = int(input(), 2)
d = int(input(), 2)
m = int(input(), 2)

days = 0
while m.bit_length() >= d:
    m2 = m
    m >>= d
    m += s
    days += d
    
    if m2 <= m:
        print('Infinite money!')
        exit()


days += m.bit_length()

print(bin(days)[2:])
