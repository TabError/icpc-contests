#!/usr/bin/python3

def forever():
    print("Infinite money!")
    exit(0)

def print_bin(x):
    print("{:b}".format(x))
    exit(0)

s = int(input(), 2)
d = int(input(), 2)
m = int(input(), 2)

init_len = m.bit_length()

if d <= s.bit_length():
    forever()

if d.bit_length() >= 12:
    print_bin(init_len)

days = 0

while m >= 2 ** d:
    days += d
    m >>= d
    m += s

days += m.bit_length()
    
print_bin(days)
