#!/usr/bin/python3
import re, sys

for _ in range(3):
    line = sys.stdin.readline()
    assert re.match("^1[01]*\n$", line)
    assert len(line.strip()) <= 1000

assert not sys.stdin.read()
sys.exit(42)
