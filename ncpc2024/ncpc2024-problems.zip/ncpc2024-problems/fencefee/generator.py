import sys
N = int(sys.argv[1])
E = []
for i in range(N):
    for j in range(N):
        E.append((i, j, i, j + 1))
        E.append((i, j, i + 1, j))
for i in range(N):
    E.append((N, i, N, i + 1))
    E.append((i, N, i + 1, N))

print(len(E))
for e in E:
    print(*e)
