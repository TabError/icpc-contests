import cmath
from math import pi
from random import shuffle
from collections import namedtuple as T

Point = T("Point", "x y")
Line = T("Line", "p1 p2")


def to_p(c):
    return Point(int(round(c.real)), int(round(c.imag)))


def from_angle(theta, radius=500):
    c = cmath.rect(radius, theta)
    cs = complex(c.real + radius, c.imag + radius)
    return to_p(cs)


def create(N=50):
    points = []
    for i in range(N):
        t = i * (2 * pi / N)
        points.append(from_angle(t))
    for i in range(len(points)):
        p = points[i]
        pn = points[(i + 1) % len(points)]
        yield Line(p, pn)


def to_problem(N):
    edges = list(create(N=N))
    shuffle(edges)
    print(len(edges))
    for p1, p2 in edges:
        print(p1.x, p1.y, p2.x, p2.y)


if __name__ == "__main__":
    from sys import argv

    if len(argv) < 2:
        exit("Usage: circle_gen N")
    to_problem(int(argv[1]))
