import matplotlib.pyplot as plt
from collections import namedtuple as T

DEBUG = False
if __name__ == "__main__":
    from sys import argv

    if len(argv) == 2:
        if "debug" in argv[1].lower():
            DEBUG = True


Point = T("Point", "x y")
Line = T("Line", "p1 p2")

LINES = []

m = input()
for _ in range(int(m)):
    a, b, c, d = map(int, input().split())
    p1 = Point(a, b)
    p2 = Point(c, d)
    l = Line(p1, p2)
    LINES.append(l)


for p1, p2 in LINES:
    x1, y1 = p1
    x2, y2 = p2
    plt.plot((x1, x2), (y1, y2), marker="o")
    if DEBUG:
        print(x1, y1, x2, y2)
plt.show()
